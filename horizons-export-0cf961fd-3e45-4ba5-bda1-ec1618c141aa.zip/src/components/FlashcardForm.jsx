
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, X } from 'lucide-react';
import { motion } from 'framer-motion';

const FlashcardForm = ({ onAddFlashcard, onClearAll, flashcardCount }) => {
  const [term, setTerm] = useState('');
  const [definition, setDefinition] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (term.trim() && definition.trim()) {
      onAddFlashcard({ term: term.trim(), definition: definition.trim() });
      setTerm('');
      setDefinition('');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-purple-500/30 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Add New Flashcard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                placeholder="Enter term or question..."
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-purple-400"
              />
            </div>
            <div>
              <Textarea
                placeholder="Enter definition or answer..."
                value={definition}
                onChange={(e) => setDefinition(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-purple-400 min-h-[100px]"
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold"
                disabled={!term.trim() || !definition.trim()}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Flashcard
              </Button>
              {flashcardCount > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClearAll}
                  className="border-red-500/50 text-red-400 hover:bg-red-500/20 hover:text-red-300"
                >
                  <X className="w-4 h-4 mr-2" />
                  Clear All
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FlashcardForm;
