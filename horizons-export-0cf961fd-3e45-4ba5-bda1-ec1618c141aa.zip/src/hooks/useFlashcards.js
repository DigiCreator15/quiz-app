
import { useState, useEffect } from 'react';

const STORAGE_KEY = 'flashcards-app-data';

export const useFlashcards = () => {
  const [flashcards, setFlashcards] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Load flashcards from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        setFlashcards(data.flashcards || []);
        setCurrentIndex(data.currentIndex || 0);
      }
    } catch (error) {
      console.error('Error loading flashcards:', error);
    }
  }, []);

  // Save flashcards to localStorage whenever they change
  useEffect(() => {
    try {
      const data = {
        flashcards,
        currentIndex: Math.min(currentIndex, Math.max(0, flashcards.length - 1))
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving flashcards:', error);
    }
  }, [flashcards, currentIndex]);

  const addFlashcard = (flashcard) => {
    const newFlashcard = {
      id: Date.now() + Math.random(),
      ...flashcard,
      createdAt: new Date().toISOString()
    };
    setFlashcards(prev => [...prev, newFlashcard]);
  };

  const removeFlashcard = (id) => {
    setFlashcards(prev => {
      const newFlashcards = prev.filter(card => card.id !== id);
      if (currentIndex >= newFlashcards.length && newFlashcards.length > 0) {
        setCurrentIndex(newFlashcards.length - 1);
      } else if (newFlashcards.length === 0) {
        setCurrentIndex(0);
      }
      return newFlashcards;
    });
  };

  const clearAllFlashcards = () => {
    setFlashcards([]);
    setCurrentIndex(0);
  };

  const shuffleFlashcards = () => {
    setFlashcards(prev => {
      const shuffled = [...prev];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      return shuffled;
    });
    setCurrentIndex(0);
  };

  const goToNext = () => {
    setCurrentIndex(prev => Math.min(prev + 1, flashcards.length - 1));
  };

  const goToPrevious = () => {
    setCurrentIndex(prev => Math.max(prev - 1, 0));
  };

  const resetToFirst = () => {
    setCurrentIndex(0);
  };

  return {
    flashcards,
    currentIndex,
    addFlashcard,
    removeFlashcard,
    clearAllFlashcards,
    shuffleFlashcards,
    goToNext,
    goToPrevious,
    resetToFirst
  };
};
