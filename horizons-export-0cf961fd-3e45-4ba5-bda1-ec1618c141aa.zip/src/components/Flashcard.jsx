
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

const Flashcard = ({ flashcard, isActive }) => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.3 }}
      className="w-full max-w-2xl mx-auto"
    >
      <div
        className="relative w-full h-80 cursor-pointer perspective-1000"
        onClick={handleFlip}
      >
        <motion.div
          className="relative w-full h-full preserve-3d"
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          style={{ transformStyle: "preserve-3d" }}
        >
          {/* Front of card */}
          <Card className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-blue-600/90 to-purple-700/90 border-blue-400/30 backdrop-blur-sm shadow-2xl">
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="mb-4">
                <span className="text-sm font-medium text-blue-200 bg-blue-500/30 px-3 py-1 rounded-full">
                  TERM
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight">
                {flashcard.term}
              </h2>
              <div className="mt-6 text-blue-200 text-sm">
                Click to reveal answer
              </div>
            </div>
          </Card>

          {/* Back of card */}
          <Card className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-emerald-600/90 to-teal-700/90 border-emerald-400/30 backdrop-blur-sm shadow-2xl rotate-y-180">
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="mb-4">
                <span className="text-sm font-medium text-emerald-200 bg-emerald-500/30 px-3 py-1 rounded-full">
                  DEFINITION
                </span>
              </div>
              <p className="text-lg md:text-xl text-white leading-relaxed">
                {flashcard.definition}
              </p>
              <div className="mt-6 text-emerald-200 text-sm">
                Click to see term
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Flashcard;
