
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Shuffle, RotateCcw } from 'lucide-react';
import { motion } from 'framer-motion';

const FlashcardControls = ({ 
  currentIndex, 
  totalCards, 
  onPrevious, 
  onNext, 
  onShuffle, 
  onReset 
}) => {
  if (totalCards === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="flex flex-col items-center gap-4"
    >
      {/* Progress indicator */}
      <div className="text-center">
        <div className="text-white/80 text-sm mb-2">
          Card {currentIndex + 1} of {totalCards}
        </div>
        <div className="w-64 bg-white/20 rounded-full h-2">
          <motion.div
            className="bg-gradient-to-r from-purple-500 to-indigo-500 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${((currentIndex + 1) / totalCards) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      {/* Navigation controls */}
      <div className="flex items-center gap-3">
        <Button
          onClick={onPrevious}
          disabled={currentIndex === 0}
          variant="outline"
          size="lg"
          className="border-white/30 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ChevronLeft className="w-5 h-5 mr-2" />
          Previous
        </Button>

        <div className="flex gap-2">
          <Button
            onClick={onShuffle}
            variant="outline"
            size="lg"
            className="border-orange-400/50 text-orange-300 hover:bg-orange-500/20 hover:text-orange-200"
          >
            <Shuffle className="w-5 h-5" />
          </Button>

          <Button
            onClick={onReset}
            variant="outline"
            size="lg"
            className="border-green-400/50 text-green-300 hover:bg-green-500/20 hover:text-green-200"
          >
            <RotateCcw className="w-5 h-5" />
          </Button>
        </div>

        <Button
          onClick={onNext}
          disabled={currentIndex === totalCards - 1}
          variant="outline"
          size="lg"
          className="border-white/30 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </motion.div>
  );
};

export default FlashcardControls;
