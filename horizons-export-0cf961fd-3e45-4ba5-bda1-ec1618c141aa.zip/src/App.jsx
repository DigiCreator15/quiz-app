
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { BookOpen, Brain } from 'lucide-react';
import FlashcardForm from '@/components/FlashcardForm';
import Flashcard from '@/components/Flashcard';
import FlashcardControls from '@/components/FlashcardControls';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { useFlashcards } from '@/hooks/useFlashcards';

function App() {
  const { toast } = useToast();
  const {
    flashcards,
    currentIndex,
    addFlashcard,
    clearAllFlashcards,
    shuffleFlashcards,
    goToNext,
    goToPrevious,
    resetToFirst
  } = useFlashcards();

  const handleAddFlashcard = (flashcard) => {
    addFlashcard(flashcard);
    toast({
      title: "Flashcard Added! 🎉",
      description: "Your new flashcard has been saved successfully.",
      duration: 3000,
    });
  };

  const handleClearAll = () => {
    clearAllFlashcards();
    toast({
      title: "All Cleared! 🧹",
      description: "All flashcards have been removed.",
      duration: 3000,
    });
  };

  const handleShuffle = () => {
    shuffleFlashcards();
    toast({
      title: "Cards Shuffled! 🔀",
      description: "Your flashcards have been randomly shuffled.",
      duration: 3000,
    });
  };

  const handleReset = () => {
    resetToFirst();
    toast({
      title: "Reset to Start! 🔄",
      description: "Back to the first flashcard.",
      duration: 3000,
    });
  };

  return (
    <>
      <Helmet>
        <title>Flashcard Generator - Learn Smarter, Study Better</title>
        <meta name="description" content="Create, study, and master your flashcards with our interactive flashcard generator. Perfect for students, professionals, and lifelong learners." />
      </Helmet>
      
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.header
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-full">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
                Flashcard Generator
              </h1>
            </div>
            <p className="text-lg text-white/80 max-w-2xl mx-auto">
              Create, study, and master your flashcards with interactive learning tools
            </p>
          </motion.header>

          <div className="grid lg:grid-cols-2 gap-8 items-start">
            {/* Form Section */}
            <div className="space-y-6">
              <FlashcardForm
                onAddFlashcard={handleAddFlashcard}
                onClearAll={handleClearAll}
                flashcardCount={flashcards.length}
              />

              {/* Stats */}
              {flashcards.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4 }}
                  className="bg-gradient-to-r from-emerald-600/20 to-teal-600/20 border border-emerald-500/30 rounded-lg p-4 backdrop-blur-sm"
                >
                  <div className="flex items-center gap-2 text-emerald-300">
                    <BookOpen className="w-5 h-5" />
                    <span className="font-semibold">
                      {flashcards.length} flashcard{flashcards.length !== 1 ? 's' : ''} ready for study!
                    </span>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Flashcard Display Section */}
            <div className="space-y-6">
              {flashcards.length > 0 ? (
                <>
                  <Flashcard
                    flashcard={flashcards[currentIndex]}
                    isActive={true}
                  />
                  <FlashcardControls
                    currentIndex={currentIndex}
                    totalCards={flashcards.length}
                    onPrevious={goToPrevious}
                    onNext={goToNext}
                    onShuffle={handleShuffle}
                    onReset={handleReset}
                  />
                </>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="text-center py-16"
                >
                  <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-purple-600/20 to-indigo-600/20 rounded-full flex items-center justify-center">
                    <BookOpen className="w-12 h-12 text-purple-400" />
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    Ready to Start Learning?
                  </h2>
                  <p className="text-white/60 max-w-md mx-auto">
                    Add your first flashcard to begin your study session. Create terms and definitions, then flip through them to test your knowledge!
                  </p>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <Toaster />
    </>
  );
}

export default App;
